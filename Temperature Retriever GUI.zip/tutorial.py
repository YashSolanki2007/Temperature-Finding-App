import tkinter as tk
from tkinter import messagebox
import requests

#Variables
WIDTH = 600
HEIGHT = 500

#Make the root
root = tk.Tk()

#Functions
def test(entry):
    print("Buttton Clicked")

def format_response(weather):
    try:
        name =weather['name']
        description=weather['weather'][0]['description']
        temperature= weather['main']['temp']
        return str(name)+'    '+str(description)+'   '+str(temperature)

        #final_st='City:%s \nConditions:%s \nTemperature in farenheit:%s'%(name,description,temperature)
    except:
        final_str='There was a problem retrieving the information'
     #return final_st

def get_weather(city):
    weather_key='a4aa5e3d83ffefaba8c00284de6ef7c3'
    url='https://api.openweathermap.org/data/2.5/weather'
    params={'APPID':weather_key,'q':city,'units':'imperial'}
    response=requests.get(url,params=params)
    weather=response.json()
    label['text']=format_response(weather)
    messagebox.showinfo("Details Found", "Temperature Retrived")

#Make the canvas
canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
canvas.pack()

#Make the frame
frame = tk.Frame(root, bg='sky blue', bd=5)
frame.place(relheight=0.15, relwidth=0.9, relx=0.05, rely=0.05)

#Make the entry
entry = tk.Entry(frame, font=40)
entry.place(relwidth=0.6, relheight=1)

#Make the Button
button = tk.Button(frame, text='Get Weather', command=lambda:get_weather(entry.get()))
button.place(relheight=1, relwidth=0.35, relx=0.64)

#Make the lower frame
lower_frame = tk.Frame(root, bg='sky blue', bd=5)
lower_frame.place(relheight=0.6, relwidth=0.9, relx=0.05, rely=0.3)

#Make the label
label = tk.Label(lower_frame, text='This Will tell you the temperature and weather of the place')
label.place(relwidth=1, relheight=1)

#MainLoop
root.title("Weather Finding App Tutorial")
root.mainloop()